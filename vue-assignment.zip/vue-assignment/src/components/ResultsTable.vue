<!-- This holds the results of the repo search -->

<template>
   <div class="result-table">
      <div class="card-group">

         <CardTemp v-for="repo in data" :key="repo.id" :id="repo.id" :name="repo.name" :description="repo.description"
            :owner-name="repo.owner.login" :num-open-issues="repo.open_issues_count" />

      </div>
   </div>
</template>

<script>
import CardTemp from './CardTemp.vue';
import repoModels from '@/models/repository';

export default {
   props: {
      data: [repoModels.miniRepo]
   },
   data()
   {
      return {

         results: this.data,
      }
   },
   components: {
      CardTemp
   }
}

</script>

<style scoped>
.card-group {

   margin: auto;
   margin-top: 5px;
   max-width: 75%
}
</style>